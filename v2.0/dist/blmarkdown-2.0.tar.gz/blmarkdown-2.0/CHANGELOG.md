# Latest Changelog
Release Date : 09/08/2021 `v2.0`
> + Code Optimization
> + Added Detailed Documentation and Example
> + Added New Function in class Learning and LearningData

# Older Changelog
Release Date : 09/07/2021 `v1.0`
> + Initial Commit

# Credit
+ Main Github Page : [https://github.com/bearaujus/](https://github.com/bearaujus/)
+ Linkedin : [https://www.linkedin.com/in/bearaujus/](https://www.linkedin.com/in/bearaujus/)

**Bear Au Jus - ジュースとくま** @2021