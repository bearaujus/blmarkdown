# Latest Changelog
Release Date : 09/07/2021 `v1.0`
> + Initial Commit

# Older Changelog
-

# Credit
+ Main Github Page : [https://github.com/bearaujus/](https://github.com/bearaujus/)
+ Linkedin : [https://www.linkedin.com/in/bearaujus/](https://www.linkedin.com/in/bearaujus/)

**Bear Au Jus - ジュースとくま** @2021